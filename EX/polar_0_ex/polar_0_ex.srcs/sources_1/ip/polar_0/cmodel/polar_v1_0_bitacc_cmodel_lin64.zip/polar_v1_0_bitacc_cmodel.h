//-----------------------------------------------------------------------------
// (c) Copyright 2017 Xilinx, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//-----------------------------------------------------------------------------

#ifndef XIP_POLAR_v1_0_BITACC_CMODEL_H
#define XIP_POLAR_v1_0_BITACC_CMODEL_H

// Common typedefs, constants and functions for use across Xilinx bit-accurate C models
#undef XIP_XILINX_XIP_TARGET
#define XIP_XILINX_XIP_TARGET polar_v1_0
#include "xip_common_bitacc_cmodel.h"

#ifdef __cplusplus
extern "C" {
#endif

//-----------------------------------------------------------------------------
#define MAX_N     2048    // Maximum codeword bits (do not change)
//-----------------------------------------------------------------------------
/**
 * xip_polar_v1_0_config Core configuration structure.
 *
 * Must be created and populated in order to instantiate the model.
 */
typedef struct {
  const char*        NAME;              /*@- Instance name to use in error/warning reporting */
} xip_polar_v1_0_config;

/**
 * Object type (opaque to user).
 */
typedef struct polar_engine xip_polar_v1_0;

typedef struct {
  xip_uint N;               /*@- Number of codeword bits */
  xip_uint K;               /*@- Number of information bits */
  xip_uint AUGMENT;         /*@- Determines augmentation to code. 0=No augmentation, 1 = Parity augment, 2 = CRC augment, 3 = both */
  xip_uint CRC_SEL;         /*@- Selection of one of 4 predefined CRC equations. 0 = CRC24c, 1 = CRC6, 2 = CRC11, 3 = CRC16 */
  xip_uint ITLV;            /*@- Selection of whether or not to apply interleave (encode) or deinterleave (decode) */
  xip_uint CRC_INIT;        /*@- Selection of whether or not to initialize CRC24c by (not to) all ones. */
  xip_uint BA_TABLE[MAX_N]; /*@- The allocation of information bits, frozen bits and crc or parity-augment bits is described in the Bit Allocation Table. 0 = Frozen, 1 = CRC, 2 = Information, 3: PC-frozen */
} xip_polar_v1_0_polar_parameters;

typedef struct {
  xip_uint ID;              /*@- External block identifier to be passed through to status output */
  xip_uint BLIND_DECODE;    /*@- Decode only. Determines whether or not to output decoded CRC with information bits or not (decoder only) */
  xip_uint EARLY_TERM;      /*@- Decode only. Determines whether or not to perform early termination (decode only) in the event that all paths become invalid */
  xip_uint RNTI;            /*@- Encode only. RNTI value for CRC Masking or Blind Decode*/
  xip_uint CODE;            /*@- Code number specifying the Polar Code Parameters used to encode the codeword */
} xip_polar_v1_0_ctrl_packet;

typedef struct {
  xip_uint ID;              /*@- External block identifier to be passed through to status output */
  xip_uint EARLY_TERM;      /*@- Indicates whether or not early termination occurred for this codeword */
  xip_uint PARITY_CRC_PASS; /*@- Indicates whether or not codeword passed applicable parity and CRC checks */
  xip_uint CODE;            /*@- Encoder only: Code number specifying the Polar Code Parameters used to encode the codeword */
  xip_uint RNTI;            /*@- candidate RNTI. This is the XOR of the last 16 bits of the calculated CRC and the received CRC */
} xip_polar_v1_0_stat_packet;
//-----------------------------------------------------------------------------
// Enumerations
// Associated with xip_polar_v1_0_polar_parameters.AUGMENT
enum { AUGMENT_NONE = 0, AUGMENT_PA = 1, AUGMENT_CRC = 2, AUGMENT_BOTH = 3 };
// Associated with xip_polar_v1_0_polar_parameters.CRC_SEL
enum { CRC_SEL_24c = 0, CRC_SEL_6 = 1, CRC_SEL_11 = 2, CRC_SEL_16 = 3 };
//-----------------------------------------------------------------------------
/**
 * Get version of library.
 *
 * @returns   String  Textual representation of library version
 */
XIP_XILINX_XIP_IMPEXP
const char* xip_polar_v1_0_get_version(void);

/**
 * Create a new instance of the core based on some configuration values.
 *
 * @param     config            Pointer to a xip_polar_v1_0_config structure
 * @param     msg_handler       Callback function for errors and warnings (or null to output to stderr/stdout)
 * @param     msg_handle        Optional argument to be passed back to callback function
 *
 * @returns   xip_polar_v1_0*   Pointer to the created xip_polar_v1_0 state structure or 0 if any error occurred
 */
XIP_XILINX_XIP_IMPEXP
xip_polar_v1_0* xip_polar_v1_0_create(
  const xip_polar_v1_0_config* config,
  xip_msg_handler msg_handler,
  void* msg_handle
);

/**
 * Reset an instance of the core.
 *
 * @param     model       Pointer to xip_polar_v1_0 state structure
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_polar_v1_0_reset(
  xip_polar_v1_0* model
);

/**
 * Generate POLAR parameters from code specification
 *
 * @param     params        Pointer to xip_polar_v1_0_polar_parameters structure
 * @param     tp_block_size E from 38.212 section 5.4.1.1
 * @param     npc           Total number of parity check bits, if params defines parity augmentation
 * @param     npc_wm        Number of parity check bits to place in minimum row weight positions,
 *                          if params defines parity augmentation
 * @param     msg_handler   Callback function for errors and warnings (or null to output to stderr/stdout)
 * @param     msg_handle    Optional argument to be passed back to callback function
 *
 * @returns   Exit code     XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_polar_v1_0_gen_polar_params(
  xip_polar_v1_0_polar_parameters* params,
  xip_uint tp_block_size,
  xip_uint npc,
  xip_uint npc_wm,
  xip_msg_handler msg_handler,
  void* msg_handle
);

/**
 * Add a Polar code
 *
 * @param     model        Pointer to xip_polar_v1_0 state structure
 * @param     code_num     Code number: 0 - 127
 * @param     params       Pointer to xip_polar_v1_0_polar_parameters containing POLAR code parameters
 * @param     msg_handler  Callback function for errors and warnings (or null to output to stderr/stdout)
 * @param     msg_handle   Optional argument to be passed back to callback function
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_polar_v1_0_add_polar_params(
  xip_polar_v1_0* model,
  xip_uint code_num,
  const xip_polar_v1_0_polar_parameters* params,
  xip_msg_handler msg_handler,
  void* msg_handle
);

/**
 * Encode a codeword
 *
 * @param     model       Pointer to xip_polar_v1_0 state structure
 * @param     ctrl        Pointer to xip_polar_v1_0_ctrl_packet
 * @param     data        Pointer to xip_array_bit structure containing codeword
 * @param     hard        Pointer to xip_array_bit structure to receive hard encoded data
 * @param     stat        Pointer to xip_polar_v1_0_stat_packet structure to receive status information
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_polar_v1_0_encode(
  xip_polar_v1_0* model,
  const xip_polar_v1_0_ctrl_packet* ctrl,
  const xip_array_bit* data,
  xip_array_bit* hard,
  xip_polar_v1_0_stat_packet* stat
);

/**
 * Decode a codeword
 *
 * @param     model       Pointer to xip_polar_v1_0 state structure
 * @param     ctrl        Pointer to xip_polar_v1_0_ctrl_packet
 * @param     data        Pointer to xip_array_real structure containing codeword
 * @param     hard        Pointer to xip_array_bit structure to receive hard decoded data
 * @param     stat        Pointer to xip_polar_v1_0_stat_packet structure to receive status information
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_polar_v1_0_decode(
  xip_polar_v1_0* model,
  const xip_polar_v1_0_ctrl_packet* ctrl,
  const xip_array_real* data,
  xip_array_bit* hard,
  xip_polar_v1_0_stat_packet* stat
);

/**
 * Destroy an instance of the core and free any resources allocated
 *
 * @param     model       Pointer to xip_polar_v1_0 state structure
 * @returns   Exit code   XIP_STATUS_*
 *
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_polar_v1_0_destroy(
  xip_polar_v1_0* model
);

#ifdef __cplusplus
} /* End of "C" linkage block */
#endif

#endif
