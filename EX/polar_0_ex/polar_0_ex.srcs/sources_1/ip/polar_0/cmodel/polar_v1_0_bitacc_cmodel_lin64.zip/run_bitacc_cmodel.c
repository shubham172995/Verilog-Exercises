//-----------------------------------------------------------------------------
// (c) Copyright 2017-2018 Xilinx, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//-----------------------------------------------------------------------------

#include "polar_v1_0_bitacc_cmodel.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <vector>
#include <string>
#include <ctime>

//---------------------------------------------------------------------------------------------------------------------

// Example message handler
static void msg_print(void* handle, int error, const char* msg) {
  std::cout << "MSG: " << msg << std::endl;
}

//---------------------------------------------------------------------------------------------------------------------

int main() {

#define NUM_BLOCKS 5
#define RUN_BOTH_BLOCK
#define RUN_CRC_BLOCK
#define RUN_PA_BLOCK
#define RUN_USER_BLOCK
  //#define PRINTOUT_BA_TABLE_BOTH
  //#define PRINTOUT_BA_TABLE_CRC
  //#define PRINTOUT_BA_TABLE_PA
#define ADD_ERRORS_TO_BOTH_BLOCK
#define ADD_ERRORS_TO_CRC_BLOCK
#define ADD_ERRORS_TO_PA_BLOCK
#define ADD_ERRORS_TO_USER_BLOCK

  // Initialize random seed
  srand (time(NULL));

  // Polar Code Parameters for BOTH augmention (typical of uplink)
  xip_polar_v1_0_polar_parameters params_BOTH;
  params_BOTH.N         = 256;           // Number of codeword bits
  params_BOTH.K         = 80;            // Number of information bits
  params_BOTH.AUGMENT   = AUGMENT_BOTH;  // Determines augmentation to code. 0 = CRC, 1 = PA. Behaviour of Augment = 2 or 3 is not defined
  params_BOTH.CRC_SEL   = CRC_SEL_6;     // Determines CRC polynomial to use when AUGMENT is set to CRC or BOTH. Ignored otherwise.
  params_BOTH.CRC_INIT  = 0;             // Determines whether or not to prime CRC generator with 1's. 
  params_BOTH.ITLV      = 0;             // Apply interleave/deinterleave stage
  int code_num_BOTH     = 0;             // Code number used to specify which set of Polar Code Parameters are to be used on the codeword [0 : 127]
  int rnti_BOTH         = 0x0000;        // Encoder only RNTI is used when ITLV is set. In decode, if BLIND_DECODE is set, candidate RNTI is output on STATUS
  int blind_decode_BOTH = 0;             // Decoder only. if BLIND_DECODE is set, candidate RNTI is output on STATUS and received CRC bits output in DOUT. 
  xip_uint tp_block_size_BOTH = 4080;    // E factor from 38.212 section 5.4.1.1.
  int npc_BOTH          = 3;             // Number of parity check bits when augmentation is set to PA or BOTH
  int npc_wm_BOTH       = 1;             // Number of parity check bits to place in minimum row weight positions

  // Polar Code Parameters for CRC augmented (typical of downlink)
  xip_polar_v1_0_polar_parameters params_CRC;
  params_CRC.N          = 512;           // Number of codeword bits
  params_CRC.K          = 27;           // Number of information bits
  params_CRC.AUGMENT    = AUGMENT_CRC;   // Determines augmentation to code. 0 = CRC, 1 = PA. Behaviour of Augment = 2 or 3 is not defined
  params_CRC.CRC_SEL    = CRC_SEL_24c;   // Determines CRC polynomial to use when AUGMENT is set to CRC or BOTH. Ignored otherwise.
  params_CRC.CRC_INIT   = 0;             // Determines whether or not to prime CRC generator with 1's. Must match ITLV
  params_CRC.ITLV       = 1;             // Apply interleave/deinterleave stage
  int code_num_CRC      = 1;             // Code number used to specify which set of Polar Code Parameters are to be used on the codeword [0 : 127]
  int rnti_CRC          = 0x0000;        // Encoder only RNTI is used when ITLV is set. In decode, if BLIND_DECODE is set, candidate RNTI is output on STATUS
  int blind_decode_CRC  = 0;             // Decoder only. if BLIND_DECODE is set, candidate RNTI is output on STATUS and received CRC bits output in DOUT.  
  xip_uint tp_block_size_CRC = 763;      // E factor from 38.212 section 5.4.1.1.
  int npc_CRC           = 0;             // Number of parity check bits when augmentation is set to PA or BOTH
  int npc_wm_CRC        = 0;             // Number of parity check bits to place in minimum row weight positions

  // Polar Code Parameters for PA augmented (simply for comparison)
  xip_polar_v1_0_polar_parameters params_PA;
  params_PA.N           = 1024;          // Number of codeword bits
  params_PA.K           = 200;           // Number of information bits
  params_PA.AUGMENT     = AUGMENT_PA;    // Determines augmentation to code. 0 = CRC, 1 = PA. Behaviour of Augment = 2 or 3 is not defined
  params_PA.CRC_SEL     = CRC_SEL_24c;   // Determines CRC polynomial to use when AUGMENT is set to CRC or BOTH. Ignored otherwise.
  params_PA.CRC_INIT    = 0;             // Determines whether or not to prime CRC generator with 1's.
  params_PA.ITLV        = 0;             // Apply interleave/deinterleave stage
  int code_num_PA       = 2;             // Code number used to specify which set of Polar Code Parameters are to be used on the codeword [0 : 127]
  int rnti_PA           = 0x0000;        // Encoder only RNTI is used when ITLV is set. In decode, if BLIND_DECODE is set, candidate RNTI is output on STATUS
  int blind_decode_PA   = 0;             // Decoder only. if BLIND_DECODE is set, candidate RNTI is output on STATUS and received CRC bits output in DOUT.  
  xip_uint tp_block_size_PA = 763;       // E factor from 38.212 section 5.4.1.1.
  int npc_PA            = 3;             // Number of parity check bits when augmentation is set to PA or BOTH
  int npc_wm_PA         = 1;             // Number of parity check bits to place in minimum row weight positions

  // Polar Code Parameters with user-defined bit allocation table
  xip_polar_v1_0_polar_parameters params_USER;
  params_USER.N         = 128;           // Number of codeword bits
  params_USER.K         = 20;            // Number of information bits
  params_USER.AUGMENT   = AUGMENT_PA;    // Determines augmentation to code. 0 = CRC, 1 = PA. Behaviour of Augment = 2 or 3 is not defined
  params_USER.CRC_SEL   = CRC_SEL_24c;   // Determines CRC polynomial to use when AUGMENT is set to CRC or BOTH. Ignored otherwise.
  params_USER.CRC_INIT  = 0;             // Determines whether or not to prime CRC generator with 1's.
  params_USER.ITLV      = 0;             // Apply interleave/deinterleave stage
  int code_num_USER     = 3;             // Code number used to specify which set of Polar Code Parameters are to be used on the codeword [0 : 127]
  int rnti_USER         = 0x0000;        // Encoder only RNTI is used when ITLV is set. In decode, if BLIND_DECODE is set, candidate RNTI is output on STATUS
  int blind_decode_USER = 0;             // Decoder only. if BLIND_DECODE is set, candidate RNTI is output on STATUS and received CRC bits output in DOUT.
  //no npc or npc_wm defined since this is for a user-defined code.

  

  std::cout << "POLAR C model version: " << xip_polar_v1_0_get_version() << std::endl;

  // The allocation of information bits, frozen bits and crc or parity-augment bits is described in the Bit Allocation Table entry for each code.
  // This table entry can be generated using xip_polar_v1_0_gen_polar_params or may be defined by the user.
  // To use xip_polar_v1_0_gen_polar_params you must first populate params.N, params.K, params.AUGMENT, params.CRC_SEL and params.ITLV before the call.
  // params.BA_TABLE will be populated by the function, so params is both an input and output of xip_polar_v1_0_gen_polar_params.

#ifdef RUN_BOTH_BLOCK
  if (xip_polar_v1_0_gen_polar_params(&params_BOTH, tp_block_size_BOTH, npc_BOTH, npc_wm_BOTH, &msg_print, 0) == XIP_STATUS_ERROR) {
    std::cout << "ERROR: POLAR parameters generation (BOTH)" << std::endl;
    return 1;
  }
#endif
#ifdef PRINTOUT_BA_TABLE_BOTH
  for (int i = 0; i < params_BOTH.N; i++) {
    printf("%d, ",params_BOTH.BA_TABLE[i]);
    if (i % 32 == 31) printf("\n");
  }
#endif

#ifdef RUN_CRC_BLOCK
  if (xip_polar_v1_0_gen_polar_params(&params_CRC, tp_block_size_CRC, npc_CRC, npc_wm_CRC, &msg_print, 0) == XIP_STATUS_ERROR) {
    std::cout << "ERROR: POLAR parameters generation (CRC AUGMENTED)" << std::endl;
    return 1;
  }
#endif
#ifdef PRINTOUT_BA_TABLE_CRC
  for (int i = 0; i < params_CRC.N; i++) {
    printf("%d, ",params_CRC.BA_TABLE[i]);
    if (i % 32 == 31) printf("\n");
  }
#endif
  
#ifdef RUN_PA_BLOCK
  if (xip_polar_v1_0_gen_polar_params(&params_PA, tp_block_size_PA, npc_PA, npc_wm_PA, &msg_print, 0) == XIP_STATUS_ERROR) {
    std::cout << "ERROR: POLAR parameters generation (PA AUGMENTED)" << std::endl;
    return 1;
  }
#endif
#ifdef PRINTOUT_BA_TABLE_PA
  for (int i = 0; i < params_PA.N; i++) {
    printf("%d, ",params_PA.BA_TABLE[i]);
    if (i % 32 == 31) printf("\n");
  }
#endif


  // User-defined Bit Allocation Table. This method will bypass the xip_polar_v1_0_gen_polar_params function call.
  // However, the user must assign this directly to params_USER.BA_TABLE.
  // The hard-coded array size (128) must match params_USER.N.
  xip_uint CUSTOMIZED_BA_TABLE [128] = {  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
                                          0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
                                          0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
                                          0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  2,  2,  2,
                                          0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
                                          0,  0,  0,  0,  0,  0,  0,  2,  0,  0,  0,  2,  0,  2,  2,  2,
                                          0,  0,  0,  0,  0,  0,  0,  2,  0,  0,  0,  2,  3,  2,  2,  2,
                                          0,  0,  3,  2,  3,  2,  3,  2,  3,  3,  3,  2,  2,  3,  2,  2
                                       };
  for (int i = 0; i < params_USER.N; i++) {
    params_USER.BA_TABLE[i] = CUSTOMIZED_BA_TABLE[i];
  }

  // Create configuration structure
  xip_polar_v1_0_config config;
  config.NAME = "POLAR CODER";


  // Create instance of the polar model
  xip_polar_v1_0* polar = xip_polar_v1_0_create(&config, &msg_print, 0);

  if (!polar) {
    std::cout << "Failed to create POLAR instance" << std::endl;
    return 1;
  }

  // Add code definitions to the model
  if (xip_polar_v1_0_add_polar_params(polar, code_num_BOTH, &params_BOTH, &msg_print, 0) == XIP_STATUS_ERROR) {
    std::cout << "Failed to add POLAR code parameters (BOTH)" << std::endl;
    return 1;
  }
  if (xip_polar_v1_0_add_polar_params(polar, code_num_CRC, &params_CRC, &msg_print, 0) == XIP_STATUS_ERROR) {
    std::cout << "Failed to add POLAR code parameters (CRC AUGMENTED)" << std::endl;
    return 1;
  }
  if (xip_polar_v1_0_add_polar_params(polar, code_num_PA, &params_PA, &msg_print, 0) == XIP_STATUS_ERROR) {
    std::cout << "Failed to add POLAR code parameters (PA AUGMENTED)" << std::endl;
    return 1;
  }
  if (xip_polar_v1_0_add_polar_params(polar, code_num_USER, &params_USER, &msg_print, 0) == XIP_STATUS_ERROR) {
    std::cout << "Failed to add POLAR code parameters (USER-DEFINED CODE CONSTRUCTOR)" << std::endl;
    return 1;
  }

#ifdef RUN_BOTH_BLOCK
  //---------------------------------------------------------------------------------------------------------------------
  // Execution of block with both CRC and Parity augmentation

  std::cout << "POLAR CODER WITH BOTH AUGMENTATIONS, N = " << params_BOTH.N << " K = " << params_BOTH.K << std::endl;
  // Print out the statistics
  std::cout << "ID "
            << "CODE "
            << "Input Errors "
            << "Bit Errors "
            << "PASS "
            << std::endl;

  for (int block = 0; block < NUM_BLOCKS; block++) {
    // Create data structures to hold input and output data sets

    // bin is message vector (K-bits) and input of the encoder
    xip_array_bit* bin = xip_array_bit_create();
    xip_array_bit_reserve_dim(bin, 1);
    bin->dim_size = 1;
    bin->dim[0] = params_BOTH.K;
    bin->data_size = bin->dim[0];
    if (xip_array_bit_reserve_data(bin, bin->data_size) == XIP_STATUS_ERROR) {
      std::cout << "Failed to reserve data array (BOTH)" << std::endl;
      return 1;
    }

    // llr is likelihood-ratio vector (N LLRs) and input of the decoder
    xip_array_real* llr = xip_array_real_create();
    xip_array_real_reserve_dim(llr, 1);
    llr->dim_size = 1;
    llr->dim[0] = params_BOTH.N;
    llr->data_size = llr->dim[0];
    if (xip_array_real_reserve_data(llr, llr->data_size) == XIP_STATUS_ERROR) {
      std::cout << "Failed to reserve data array (BOTH)" << std::endl;
      return 1;
    }

    // encb is encoded vector (N-bits) and decb is the decoded vector (K-bits)
    // these only need to be initialized here and all necessary reservations
    // will happen internally in encode and decode functions
    xip_array_bit* encb = xip_array_bit_create();
    xip_array_bit* decb = xip_array_bit_create();

    // Control struct. This tells the model which code definition to use for the block in question and supplies an ID field for this block
    xip_polar_v1_0_ctrl_packet ctrl;
    ctrl.ID           = block;
    ctrl.CODE         = code_num_BOTH;
    ctrl.BLIND_DECODE = blind_decode_BOTH;
    ctrl.RNTI         = rnti_BOTH;           //RNTI for CRC Masking. Only used for interleaved codewords with CRC 


    // Status struct. This represents status after encoder and decoder functions
    // Decoder function will also change stat.PARITY_CRC_PASS flag which indicates success or failure of parity or CRC for output codeword
    xip_polar_v1_0_stat_packet stat;

    // Generation of randomized message vector
    for (int i = 0; i < bin->data_size; i++) {
      if ((rand() % 100) > 50) {
        bin->data[i] = 1;
      } else {
        bin->data[i] = 0;
      }
    }

    // Perform encoder operation
    if (xip_polar_v1_0_encode(polar, &ctrl, bin, encb, &stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to encode (BOTH)" << std::endl;
      return 1;
    }

    // Corrupt encoded bits and convert to LLRs
    // This is neither an accurate channel model nor a representative conversion of received values to LLRs,
    // but is simplified for the purpose of demonstration
    int err_target = rand() % 100;
    int err_bits = 0;
    for (int i = 0; i < params_BOTH.N; i++) {
      //Convert bit to LLR 
      if (encb->data[i] == 0) {
        llr->data[i] = -4;
      } else {
        llr->data[i] = 4;
      }
#ifdef ADD_ERRORS_TO_BOTH_BLOCK
      if (err_bits != err_target) {
        if ((rand() % 100) > 90) {
          llr->data[i] = -1 * llr->data[i];
          err_bits++;
        }
      }
#endif
    }

    // Perform decoder operation
    if (xip_polar_v1_0_decode(polar, &ctrl, llr, decb, &stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to decode (BOTH)" << std::endl;
      return 1;
    }

    // Compare inputs to outputs for error calculation
    int num_errors = 0;
    for (int i = 0; i < bin->data_size; i++) {
      if (decb->data[i] != bin->data[i]) {
        num_errors++;
      }
    }

    // Print out the statistics
    std::cout << std::setiosflags(std::ios::left)
              << std::setw(3)  << stat.ID
              << std::setw(5)  << stat.CODE
              << std::setw(13) << err_bits
              << std::setw(11) << num_errors
              << std::setw(5)  << (unsigned) stat.PARITY_CRC_PASS
              << std::endl;

    // Deallocation of initialized objects
    xip_array_bit_destroy(bin);
    xip_array_bit_destroy(encb);
    xip_array_real_destroy(llr);
    xip_array_bit_destroy(decb);
  }
#endif

#ifdef RUN_CRC_BLOCK
  //---------------------------------------------------------------------------------------------------------------------
  // Execution of CRC augmented

  std::cout << "POLAR CODER WITH CRC AUGMENTED, N = " << params_CRC.N << " K = " << params_CRC.K << std::endl;
  // Print out the statistics
  std::cout << "ID "
            << "CODE "
            << "Input Errors "
            << "Bit Errors "
            << "PASS "
            << std::endl;

  for (int block = 0; block < NUM_BLOCKS; block++) {
    // Create data structures to hold input and output data sets

    // bin is message vector (K-bits) and input of the encoder
    xip_array_bit* bin = xip_array_bit_create();
    xip_array_bit_reserve_dim(bin, 1);
    bin->dim_size = 1;
    bin->dim[0] = params_CRC.K;
    bin->data_size = bin->dim[0];
    if (xip_array_bit_reserve_data(bin, bin->data_size) == XIP_STATUS_ERROR) {
      std::cout << "Failed to reserve data array (CRC AUGMENTED)" << std::endl;
      return 1;
    }

    // llr is likelihood-ratio vector (N LLRs) and input of the decoder
    xip_array_real* llr = xip_array_real_create();
    xip_array_real_reserve_dim(llr, 1);
    llr->dim_size = 1;
    llr->dim[0] = params_CRC.N;
    llr->data_size = llr->dim[0];
    if (xip_array_real_reserve_data(llr, llr->data_size) == XIP_STATUS_ERROR) {
      std::cout << "Failed to reserve data array (CRC AUGMENTED)" << std::endl;
      return 1;
    }

    // encb is encoded vector (N-bits) and decb is the decoded vector (K-bits)
    // these only need to be initialized here and all necessary reservations
    // will happen internally in encode and decode functions
    xip_array_bit* encb = xip_array_bit_create();
    xip_array_bit* decb = xip_array_bit_create();

    // Control struct. This tells the model which code definition to use for the block in question and supplies an ID field for this block
    xip_polar_v1_0_ctrl_packet ctrl;
    ctrl.ID           = block;
    ctrl.CODE         = code_num_CRC;
    ctrl.BLIND_DECODE = blind_decode_CRC;
    ctrl.RNTI         = rnti_CRC;        //RNTI for CRC Masking

    // Status struct. This represents status after encoder and decoder functions
    // Decoder function will also change stat.PARITY_CRC_PASS flag which indicates success or failure of parity or CRC for output codeword
    xip_polar_v1_0_stat_packet stat;

    // Generation of randomized message vector
    for (int i = 0; i < bin->data_size; i++) {
      bin->data[i] = 0;
      if ((rand() % 100) > 50) {
        bin->data[i] = 1;
      } else {
        bin->data[i] = 0;
      }
    }

    // Perform encoder operation
    if (xip_polar_v1_0_encode(polar, &ctrl, bin, encb, &stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to encode (CRC AUGMENTED)" << std::endl;
      return 1;
    }

    // Corrupt encoded bits and convert to LLRs
    // This is neither an accurate channel model nor a representative conversion of received values to LLRs,
    // but is simplified for the purpose of demonstration
    int err_target = rand() % 100;
    int err_bits = 0;
    for (int i = 0; i < params_CRC.N; i++) {
      //Convert bit to LLR 
      if (encb->data[i] == 0) {
        llr->data[i] = -4;
      } else {
        llr->data[i] = 4;
      }
#ifdef ADD_ERRORS_TO_CRC_BLOCK
      if (err_bits != err_target) {
        if ((rand() % 100) > 90) {
          llr->data[i] = -1 * llr->data[i];
          err_bits++;
        }
      }
#endif
    }

    // Perform decoder operation
    if (xip_polar_v1_0_decode(polar, &ctrl, llr, decb, &stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to decode (CRC AUGMENTED)" << std::endl;
      return 1;
    }

    // Compare inputs to outputs for error calculation
    int num_errors = 0;
    for (int i = 0; i < bin->data_size; i++) {
      if (decb->data[i] != bin->data[i]) {
        num_errors++;
      }
    }
    if (ctrl.BLIND_DECODE ) {
      printf("rx crc follows, lsb first\n");
      for (int i = bin->data_size; i < bin->data_size + 24; i++) {
        printf("%d, ", decb->data[i]);
      }
      printf("\n");
    }

    // Print out the statistics
    std::cout << std::setiosflags(std::ios::left)
              << std::setw(3)  << stat.ID
              << std::setw(5)  << stat.CODE
              << std::setw(13) << err_bits
              << std::setw(11) << num_errors
              << std::setw(5)  << (unsigned) stat.PARITY_CRC_PASS
              << std::endl;

    // Deallocation of initialized objects
    xip_array_bit_destroy(bin);
    xip_array_bit_destroy(encb);
    xip_array_real_destroy(llr);
    xip_array_bit_destroy(decb);
  }
#endif

#ifdef RUN_PA_BLOCK
  //---------------------------------------------------------------------------------------------------------------------
  // Execution of PA augmented

  std::cout << "POLAR CODER WITH PA AUGMENTED, N = " << params_PA.N << " K = " << params_PA.K << std::endl;
  // Print out the statistics
  std::cout << "ID "
            << "CODE "
            << "Input Errors "
            << "Bit Errors "
            << "PASS "
            << std::endl;

  for (int block = 0; block < NUM_BLOCKS; block++) {
    // Create data structures to hold input and output data sets

    // bin is message vector (K-bits) and input of the encoder
    xip_array_bit* bin = xip_array_bit_create();
    xip_array_bit_reserve_dim(bin, 1);
    bin->dim_size = 1;
    bin->dim[0] = params_PA.K;
    bin->data_size = bin->dim[0];
    if (xip_array_bit_reserve_data(bin, bin->data_size) == XIP_STATUS_ERROR) {
      std::cout << "Failed to reserve data array (PA AUGMENTED)" << std::endl;
      return 1;
    }

    // llr is likelihood-ratio vector (N LLRs) and input of the decoder
    xip_array_real* llr = xip_array_real_create();
    xip_array_real_reserve_dim(llr, 1);
    llr->dim_size = 1;
    llr->dim[0] = params_PA.N;
    llr->data_size = llr->dim[0];
    if (xip_array_real_reserve_data(llr, llr->data_size) == XIP_STATUS_ERROR) {
      std::cout << "Failed to reserve data array (PA AUGMENTED)" << std::endl;
      return 1;
    }

    // encb is encoded vector (N-bits) and decb is the decoded vector (K-bits)
    // these only need to be initialized here and all necessary reservations
    // will happen internally in encode and decode functions
    xip_array_bit* encb = xip_array_bit_create();
    xip_array_bit* decb = xip_array_bit_create();

    // Control struct. This tells the model which code definition to use for the block in question and supplies an ID field for this block
    xip_polar_v1_0_ctrl_packet ctrl;
    ctrl.ID = block;
    ctrl.CODE = code_num_PA;
    ctrl.BLIND_DECODE = blind_decode_PA;
    ctrl.RNTI = rnti_PA;           //RNTI for CRC Masking. Not used for PA.

    // Status struct. This represents status after encoder and decoder functions
    // Decoder function will also change stat.PARITY_CRC_PASS flag which indicates success or failure of parity or CRC for output codeword
    xip_polar_v1_0_stat_packet stat;

    // Generation of randomized message vector
    for (int i = 0; i < bin->data_size; i++) {
      if ((rand() % 100) > 50) {
        bin->data[i] = 1;
      } else {
        bin->data[i] = 0;
      }
    }

    // Perform encoder operation
    if (xip_polar_v1_0_encode(polar, &ctrl, bin, encb, &stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to encode (PA AUGMENTED)" << std::endl;
      return 1;
    }

    // Corrupt encoded bits and convert to LLRs
    // This is neither an accurate channel model nor a representative conversion of received values to LLRs,
    // but is simplified for the purpose of demonstration
    int err_target = rand() % 100;
    int err_bits = 0;
    for (int i = 0; i < params_PA.N; i++) {
      //Convert bit to LLR 
      if (encb->data[i] == 0) {
        llr->data[i] = -4;
      } else {
        llr->data[i] = 4;
      }
#ifdef ADD_ERRORS_TO_PA_BLOCK
      if (err_bits != err_target) {
        if ((rand() % 100) > 90) {
          llr->data[i] = -1 * llr->data[i];
          err_bits++;
        }
      }
#endif
    }

    // Perform decoder operation
    if (xip_polar_v1_0_decode(polar, &ctrl, llr, decb, &stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to decode (PA AUGMENTED)" << std::endl;
      return 1;
    }

    // Compare inputs to outputs for error calculation
    int num_errors = 0;
    for (int i = 0; i < bin->data_size; i++) {
      if (decb->data[i] != bin->data[i]) {
        num_errors++;
      }
    }

    // Print out the statistics
    std::cout << std::setiosflags(std::ios::left)
              << std::setw(3)  << stat.ID
              << std::setw(5)  << stat.CODE
              << std::setw(13) << err_bits
              << std::setw(11) << num_errors
              << std::setw(5)  << (unsigned) stat.PARITY_CRC_PASS
              << std::endl;

    // Deallocation of initialized objects
    xip_array_bit_destroy(bin);
    xip_array_bit_destroy(encb);
    xip_array_real_destroy(llr);
    xip_array_bit_destroy(decb);

  }
#endif

#ifdef RUN_USER_BLOCK
  //---------------------------------------------------------------------------------------------------------------------
  // Execution of user-defined code constructor

  std::cout << "POLAR CODER WITH USER-DEFINED CODE CONSTRUCTOR, N = " << params_USER.N << " K = " << params_USER.K << std::endl;
  // Print out the statistics
  std::cout << "ID "
            << "CODE "
            << "Input Errors "
            << "Bit Errors "
            << "PASS "
            << std::endl;

  for (int block = 0; block < NUM_BLOCKS; block++) {
    // Create data structures to hold input and output data sets

    // bin is message vector (K-bits) and input of the encoder
    xip_array_bit* bin = xip_array_bit_create();
    xip_array_bit_reserve_dim(bin, 1);
    bin->dim_size = 1;
    bin->dim[0] = params_USER.K;
    bin->data_size = bin->dim[0];
    if (xip_array_bit_reserve_data(bin, bin->data_size) == XIP_STATUS_ERROR) {
      std::cout << "Failed to reserve data array (USER-DEFINED CODE CONSTRUCTOR)" << std::endl;
      return 1;
    }

    // llr is likelihood-ratio vector (N LLRs) and input of the decoder
    xip_array_real* llr = xip_array_real_create();
    xip_array_real_reserve_dim(llr, 1);
    llr->dim_size = 1;
    llr->dim[0] = params_USER.N;
    llr->data_size = llr->dim[0];
    if (xip_array_real_reserve_data(llr, llr->data_size) == XIP_STATUS_ERROR) {
      std::cout << "Failed to reserve data array (USER-DEFINED CODE CONSTRUCTOR)" << std::endl;
      return 1;
    }

    // encb is encoded vector (N-bits) and decb is the decoded vector (K-bits)
    // these only need to be initialized here and all necessary reservations
    // will happen internally in encode and decode functions
    xip_array_bit* encb = xip_array_bit_create();
    xip_array_bit* decb = xip_array_bit_create();

    // Control struct. This tells the model which code definition to use for the block in question and supplies an ID field for this block
    xip_polar_v1_0_ctrl_packet ctrl;
    ctrl.ID           = block;
    ctrl.CODE         = code_num_USER;
    ctrl.BLIND_DECODE = blind_decode_USER;
    ctrl.RNTI         = rnti_USER;        //RNTI for CRC Masking

    // Status struct. This represents status after encoder and decoder functions
    // Decoder function will also change stat.PARITY_CRC_PASS flag which indicates success or failure of parity or CRC for output codeword
    xip_polar_v1_0_stat_packet stat;

    // Generation of randomized message vector
    for (int i = 0; i < bin->data_size; i++) {
      if ((rand() % 100) > 50) {
        bin->data[i] = 1;
      } else {
        bin->data[i] = 0;
      }
    }

    // Perform encoder operation
    if (xip_polar_v1_0_encode(polar, &ctrl, bin, encb, &stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to encode (USER-DEFINED CODE CONSTRUCTOR)" << std::endl;
      return 1;
    }

    // Corrupt encoded bits and convert to LLRs
    // This is neither an accurate channel model nor a representative conversion of received values to LLRs,
    // but is simplified for the purpose of demonstration
    int err_target = rand() % 100;
    int err_bits = 0;
    for (int i = 0; i < params_USER.N; i++) {
      //Convert bit to LLR 
      if (encb->data[i] == 0) {
        llr->data[i] = -4;
      } else {
        llr->data[i] = 4;
      }
#ifdef ADD_ERRORS_TO_USER_BLOCK
      if (err_bits != err_target) {
        if ((rand() % 100) > 90) {
          llr->data[i] = -1 * llr->data[i];
          err_bits++;
        }
      }
#endif
    }

    // Perform decoder operation
    if (xip_polar_v1_0_decode(polar, &ctrl, llr, decb, &stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to decode (USER-DEFINED CODE CONSTRUCTOR)" << std::endl;
      return 1;
    }

    // Compare inputs to outputs for error calculation
    int num_errors = 0;
    for (int i = 0; i < bin->data_size; i++) {
      if (decb->data[i] != bin->data[i]) {
        num_errors++;
      }
    }

    // Print out the statistics
    std::cout << std::setiosflags(std::ios::left)
              << std::setw(3)  << stat.ID
              << std::setw(5)  << stat.CODE
              << std::setw(13) << err_bits
              << std::setw(11) << num_errors
              << std::setw(5)  << (unsigned) stat.PARITY_CRC_PASS
              << std::endl;

    // Deallocation of initialized objects
    xip_array_bit_destroy(bin);
    xip_array_bit_destroy(encb);
    xip_array_real_destroy(llr);
    xip_array_bit_destroy(decb);

  }
#endif
  //---------------------------------------------------------------------------------------------------------------------

  xip_polar_v1_0_destroy(polar);

  return 0;
}
