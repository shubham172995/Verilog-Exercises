% -----------------------------------------------------------------------------
%  (c) Copyright 2018 Xilinx, Inc. All rights reserved.
%
%  This file contains confidential and proprietary information
%  of Xilinx, Inc. and is protected under U.S. and
%  international copyright and other intellectual property
%  laws.
%
%  DISCLAIMER
%  This disclaimer is not a license and does not grant any
%  rights to the materials distributed herewith. Except as
%  otherwise provided in a valid license issued to you by
%  Xilinx, and to the maximum extent permitted by applicable
%  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
%  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
%  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
%  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
%  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
%  (2) Xilinx shall not be liable (whether in contract or tort,
%  including negligence, or under any other theory of
%  liability) for any loss or damage of any kind or nature
%  related to, arising under or in connection with these
%  materials, including for any direct, or any indirect,
%  special, incidental, or consequential loss or damage
%  (including loss of data, profits, goodwill, or any type of
%  loss or damage suffered as a result of any action brought
%  by a third party) even if such damage or loss was
%  reasonably foreseeable or Xilinx had been advised of the
%  possibility of the same.
%
%  CRITICAL APPLICATIONS
%  Xilinx products are not designed or intended to be fail-
%  safe, or for use in any application requiring fail-safe
%  performance, such as life-support or safety devices or
%  systems, Class III medical devices, nuclear facilities,
%  applications related to the deployment of airbags, or any
%  other applications that could lead to death, personal
%  injury, or severe property or environmental damage
%  (individually and collectively, "Critical
%  Applications"). Customer assumes the sole risk and
%  liability of any use of Xilinx products in Critical
%  Applications, subject only to applicable laws and
%  regulations governing limitations on product liability.
%
%  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
%  PART OF THIS FILE AT ALL TIMES.
% -----------------------------------------------------------------------------

clear all
clc

OP.GET_VERSION      = 0;
OP.CREATE           = 1;
OP.DESTROY          = 2;
OP.RESET            = 3;
OP.GEN_POLAR_PARAMS = 4;
OP.ADD_POLAR_PARAMS = 5;
OP.ENCODE           = 8;
OP.DECODE           = 9;

% Polar Code Parameters
cnfg.NAME         = 'POLAR CODER';

% Polar Code Parameters for CRC augmented
params_CRC.N         = 1024;     % Number of codeword bits
params_CRC.K         = 200;      % Number of information bits
params_CRC.AUGMENT   = 2;        % Determines augmentation to code. 0 = No augmentation, 1 = PA, 2 = CRC, 3 = BOTH (non-interleaved).
params_CRC.CRC_SEL   = 0;        % Selection of one of 4 predefined CRC equations when augmentation uses CRC. 0 = CRC24c, 1 = CRC6, 2 = CRC11, 3 = CRC16 See 3GPP TS 38.212 section 5.1
params_CRC.CRC_INIT  = 0;        % Determines if CRC generator/detector is to be primed as in 3GPP TS 38.212 section 7.3.2
params_CRC.ITLV      = 0;        % Determines if interleave/deinterleave is to be used as in 3GPP TS 38.212 section 5.3.1
params_CRC.BA_TABLE  = [];

% Polar Code Parameters for PA augmented
params_PA.N          = 1024;     % Number of codeword bits
params_PA.K          = 200;      % Number of information bits
params_PA.AUGMENT    = 3;        % Determines augmentation to code. 0 = No augmentation, 1 = PA, 2 = CRC, 3 = BOTH (non-interleaved).
params_PA.CRC_SEL    = 0;        % Selection of one of 4 predefined CRC equations when augmentation uses CRC. 0 = CRC24c, 1 = CRC6, 2 = CRC11, 3 = CRC16 See 3GPP TS 38.212 section 5.1
params_PA.CRC_INIT   = 0;        % Determines if CRC generator/detector is to be primed as in 3GPP TS 38.212 section 7.3.2
params_PA.ITLV       = 0;        % Determines if interleave/deinterleave is to be used as in 3GPP TS 38.212 section 5.3.1
params_PA.BA_TABLE   = [];

% The following parameters are used to create a polar code using xip_polar_v1_0_gen_polar_params
NPC                  = 3;        % Selects total number of parity bits when augmentation includes parity
NPC_WM               = 1;        % Selects number of parity bits to be placed in positions of minimum row weight. See 3GPP TS 38.212 section 5.3.1.2

% Code number used to specify which set of Polar Code Parameters are to be used on the codeword [0 : 127]
code_num_CRC         = 0;
code_num_PA          = 1;

% Create an instance of the polar model
polar = polar_v1_0_bitacc(cnfg);

% Get current version
polar_version = get_version(polar);
fprintf('POLAR model version: %s\n', polar_version);

% The allocation of information bits, frozen bits and crc or parity-augment bits is described in the Bit Allocation Table entry for each code.
% This table entry can be generated using gen_polar_params or may be defined by the user.
% To use gen_polar_params you must first populate params.N, params.K, params.AUGMENT, params.CRC_SEL, params.CRC_INIT and params.ITLV before the call.
params_CRC   = gen_polar_params(params_CRC,   0,      0);
params_PA    = gen_polar_params(params_PA,  NPC, NPC_WM);

% Add code definitions to the model
polar = add_polar_params(polar, code_num_CRC, params_CRC);
polar = add_polar_params(polar, code_num_PA,  params_PA);

% ---------------------------------------------------------------------------------------------------------------------
% Execution of CRC augmented
fprintf('POLAR CODER WITH CRC AUGMENTED\n');
for block = 1:1:5
    ctrl.ID           = block;        % External block identifier to be passed through to status output. This parameters is unused in the c-model
    ctrl.CODE         = code_num_CRC; % Code number used to specify which set of Polar Code Parameters are to be used on the codeword [0 : 127]
    ctrl.EARLY_TERM   = 0;
    ctrl.RNTI         = 0;
    ctrl.BLIND_DECODE = 0;

    % Generation of randomized message vector
    message_data = double(rand(params_CRC.K, 1) > 0.5);
    
    % Perform encoder operation
    [encode_data, encode_stat] = encode(polar, ctrl, message_data);
    
    % Corrupt encoded bits and convert to LLRs
    % This is neither an accurate channel model nor a representative conversion of received values to LLRs,
    % but is simplified for the purpose of demonstration
    llr_data = zeros(params_CRC.N, 1);
    err_target = randi(50, 1, 1);
    err_bits   = 0;
    for i = 1:1:params_CRC.N
        if (encode_data(i) == 0)
            llr_data(i) = -4;
        else
            llr_data(i) = 4;
        end
        if (err_bits ~= err_target)
%            llr_data(i) = -1 * llr_data(i);
            err_bits = err_bits + 1;
        end
    end
    
    % Perform decoder operation
    [decode_data, decode_stat] = decode(polar, ctrl, llr_data);
    
    % Compare inputs to outputs for error calculation
    num_errors = 0;
    for i = 1:1:params_CRC.K
        if (message_data(i) ~=  decode_data(i))
            num_errors = num_errors + 1;
        end
    end
    
    % Print out the statistic
    fprintf('ID \t CODE \t Input Errors \t Bit Errors \t PASS \n');
    fprintf('%d \t %1d \t %1d \t\t %1d \t\t %1d \n', ctrl.ID, ctrl.CODE, err_bits, num_errors, decode_stat.PARITY_CRC_PASS);
end

% ---------------------------------------------------------------------------------------------------------------------
% Execution of PA augmented
fprintf('POLAR CODER WITH PA AUGMENTED\n');
for block = 1:1:5
    ctrl.ID   = block;        % External block identifier to be passed through to status output. This parameters is unused in the c-model
    ctrl.CODE = code_num_PA;  % Code number used to specify which set of Polar Code Parameters are to be used on the codeword [0 : 127]

    % Generation of randomized message vector
    message_data = double(rand(params_PA.K, 1) > 0.5);
    
    % Perform encoder operation
    [encode_data, encode_stat] = encode(polar, ctrl, message_data);
    
    % Corrupt encoded bits and convert to LLRs
    % This is neither an accurate channel model nor a representative conversion of received values to LLRs,
    % but is simplified for the purpose of demonstration
    llr_data = zeros(params_PA.N, 1);
    err_target = randi(50, 1, 1);
    err_bits   = 0;
    for i = 1:1:params_PA.N
        if (encode_data(i) == 0)
            llr_data(i) = -4;
        else
            llr_data(i) = 4;
        end
        if (err_bits ~= err_target)
%            llr_data(i) = -1 * llr_data(i);
            err_bits = err_bits + 1;
        end
    end
    
    % Perform decoder operation
    [decode_data, decode_stat] = decode(polar, ctrl, llr_data);
    
    % Compare inputs to outputs for error calculation
    num_errors = 0;
    for i = 1:1:params_PA.K
        if (message_data(i) ~=  decode_data(i))
            num_errors = num_errors + 1;
        end
    end
    
    % Print out the statistic
    fprintf('ID \t CODE \t Input Errors \t Bit Errors \t PASS \n');
    fprintf('%d \t %1d \t %1d \t\t %1d \t\t %1d \n', ctrl.ID, ctrl.CODE, err_bits, num_errors, decode_stat.PARITY_CRC_PASS);
end

% Deallocation of initialized objects
destroy(polar);
